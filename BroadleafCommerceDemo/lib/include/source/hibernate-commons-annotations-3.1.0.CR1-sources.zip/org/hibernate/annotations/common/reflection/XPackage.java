package org.hibernate.annotations.common.reflection;

/**
 * @author Paolo Perrotta
 * @author Davide Marchignoli
 */
public interface XPackage extends XAnnotatedElement {

	String getName();
}
