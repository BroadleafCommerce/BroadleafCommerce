package org.hibernate.cache.access;

/**
 * Moved up from inner definition on the now deprecated
 * {@link org.hibernate.cache.CacheConcurrencyStrategy}.
 *
 * @author Steve Ebersole
 */
public interface SoftLock {
}
