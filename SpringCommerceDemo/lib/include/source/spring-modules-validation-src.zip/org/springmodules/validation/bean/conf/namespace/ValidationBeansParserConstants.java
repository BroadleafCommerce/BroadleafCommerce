package org.springmodules.validation.bean.conf.namespace;

/**
 * @author Uri Boness
 */
public interface ValidationBeansParserConstants {

    public final static String VALIDATION_BEANS_NAMESPACE = "http://www.springmodules.org/validation/bean/validator";
}
